package com.example.flutter_student

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
