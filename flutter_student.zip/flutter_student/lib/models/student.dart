class Student {
  String id;
  String name;
  String age;
  String major;

  Student({required this.id, required this.name, required this.age, required this.major});
}